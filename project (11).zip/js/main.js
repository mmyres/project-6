document.addEventListener('DOMContentLoaded', () => {
    // MediaElement.js
    $('video').mediaelementplayer();
    
    // Variables
    const video = document.getElementsByTagName("video")[0];
    const captions = document.querySelectorAll('span[data-start]');
    
    // Loop through all captions, adding class to captions 
    function highlight(time) {
        for (let i = 0; i < captions.length; i++) {
            const start = captions[i].getAttribute('data-start');
            const end = captions[i].getAttribute('data-end');
            if (time >= start && time <= end) {
                captions[i].classList.add("active");
            } else {
                captions[i].classList.remove("active");
            }
        }
    }
    
    function getTime() {
        video.addEventListener('timeupdate', () => {
           let time = video.currentTime;
            highlight(time);
        });
    }
    
    video.addEventListener('play', () => {
        getTime();
    });
    
    for (let i = 0; i < captions.length; i++) {
        const start = captions[i].getAttribute('data-start');
        captions[i].addEventListener('click', () => {
            video.currentTime = start;
        });
    }
    
})
